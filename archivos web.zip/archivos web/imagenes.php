<?php
header('Content-Type: application/json; charset=utf-8');
include("conexion.php");

$accion = $_POST["accion"] ?? "";
$idUsuario = $_POST["idUsuario"] ?? "";
$imagen = $_POST["imagen"] ?? "";

if ($accion == "subir") {

    if ($idUsuario == "" || $imagen == "") {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Faltan parametros"
        ));
        exit();
    }

    $consulta = "SELECT id FROM usuarios WHERE id = '$idUsuario'";
    $resultado = mysqli_query($con, $consulta);

    if (!$resultado) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Ha ocurrido algún error: " . mysqli_error($con)
        ));
        exit();
    }

    if (mysqli_num_rows($resultado) == 0) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Usuario no encontrado"
        ));
        exit();
    }

    if (!is_dir("uploads")) {
        mkdir("uploads", 0777, true);
    }

    $binary = base64_decode($imagen);

    if ($binary === false) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "La imagen no tiene un formato valido"
        ));
        exit();
    }

    $timeStamp = date("Ymd_His");
    $nombreFichero = "usuario_" . $idUsuario . "_" . $timeStamp . ".jpg";
    $rutaRelativa = "uploads/" . $nombreFichero;

    $file = fopen($rutaRelativa, "w+");
    fwrite($file, $binary);
    fclose($file);

    $urlfoto = obtenerBaseURL() . $rutaRelativa;

    $sql = "UPDATE usuarios SET foto = ? WHERE id = ?";
    $stmt = mysqli_prepare($con, $sql);

    $idUsuarioInt = intval($idUsuario);
    mysqli_stmt_bind_param($stmt, "si", $urlfoto, $idUsuarioInt);
    mysqli_stmt_execute($stmt);

    if (mysqli_stmt_errno($stmt) != 0) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Error de sentencia: " . mysqli_stmt_error($stmt)
        ));
        exit();
    }

    echo json_encode(array(
        "resultado" => "ok",
        "mensaje" => "Foto guardada correctamente",
        "foto" => $urlfoto
    ));
    exit();
}

echo json_encode(array(
    "resultado" => "error",
    "mensaje" => "Accion no valida"
));
?>