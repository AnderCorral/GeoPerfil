<?php
header('Content-Type: application/json; charset=utf-8');
include("conexion.php");

$accion = $_POST["accion"] ?? "";
$nombre = $_POST["nombre"] ?? "";
$email = $_POST["email"] ?? "";
$password = $_POST["password"] ?? "";
$idUsuario = $_POST["idUsuario"] ?? "";

if ($accion == "register") {

    if ($nombre == "" || $email == "" || $password == "") {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Faltan datos"
        ));
        exit();
    }

    $consulta = "SELECT id FROM usuarios WHERE email = '$email'";
    $resultado = mysqli_query($con, $consulta);

    if (!$resultado) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Ha ocurrido algún error: " . mysqli_error($con)
        ));
        exit();
    }

    if (mysqli_num_rows($resultado) > 0) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Ese email ya existe"
        ));
        exit();
    }

    $foto = "";

    $sql = "INSERT INTO usuarios (nombre, email, password, foto) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "ssss", $nombre, $email, $password, $foto);
    mysqli_stmt_execute($stmt);

    if (mysqli_stmt_errno($stmt) != 0) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Error de sentencia: " . mysqli_stmt_error($stmt)
        ));
        exit();
    }

    $idNuevo = mysqli_insert_id($con);

    echo json_encode(array(
        "resultado" => "ok",
        "mensaje" => "Usuario registrado correctamente",
        "id" => $idNuevo,
        "nombre" => $nombre,
        "email" => $email,
        "foto" => $foto
    ));
    exit();
}

if ($accion == "login") {

    if ($email == "" || $password == "") {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Faltan datos"
        ));
        exit();
    }

    $query = "SELECT * FROM usuarios WHERE email = '$email' AND password = '$password'";
    $resultado = mysqli_query($con, $query);

    if (!$resultado) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Ha ocurrido algún error: " . mysqli_error($con)
        ));
        exit();
    }

    if (mysqli_num_rows($resultado) == 0) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Credenciales incorrectas"
        ));
        exit();
    }

    $fila = mysqli_fetch_assoc($resultado);

    echo json_encode(array(
        "resultado" => "ok",
        "mensaje" => "Login correcto",
        "id" => $fila["id"],
        "nombre" => $fila["nombre"],
        "email" => $fila["email"],
        "foto" => $fila["foto"]
    ));
    exit();
}

if ($accion == "getUser") {

    if ($idUsuario == "") {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Falta el id del usuario"
        ));
        exit();
    }

    $query = "SELECT * FROM usuarios WHERE id = '$idUsuario'";
    $resultado = mysqli_query($con, $query);

    if (!$resultado) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Ha ocurrido algún error: " . mysqli_error($con)
        ));
        exit();
    }

    if (mysqli_num_rows($resultado) == 0) {
        echo json_encode(array(
            "resultado" => "error",
            "mensaje" => "Usuario no encontrado"
        ));
        exit();
    }

    $fila = mysqli_fetch_assoc($resultado);

    echo json_encode(array(
        "resultado" => "ok",
        "mensaje" => "Usuario encontrado",
        "id" => $fila["id"],
        "nombre" => $fila["nombre"],
        "email" => $fila["email"],
        "foto" => $fila["foto"]
    ));
    exit();
}

echo json_encode(array(
    "resultado" => "error",
    "mensaje" => "Accion no valida"
));
?>