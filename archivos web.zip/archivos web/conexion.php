<?php

$DB_SERVER = "db";
$DB_USER = "admin";
$DB_PASS = "test";
$DB_DATABASE = "geoperfil";

$con = mysqli_connect($DB_SERVER, $DB_USER, $DB_PASS, $DB_DATABASE);

if (mysqli_connect_errno()) {
    echo json_encode(array(
        "resultado" => "error",
        "mensaje" => "Error de conexion: " . mysqli_connect_error()
    ));
    exit();
}

mysqli_set_charset($con, "utf8");

function obtenerBaseURL() {
    $protocolo = "http://";

    if (
        isset($_SERVER["HTTPS"]) &&
        $_SERVER["HTTPS"] != "off" &&
        $_SERVER["HTTPS"] != ""
    ) {
        $protocolo = "https://";
    }

    return $protocolo . $_SERVER["HTTP_HOST"] . "/";
}
?>